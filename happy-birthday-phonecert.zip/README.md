# 🎂 Happy Birthday Phonecert – Alight Motion Template

> Template làm video sinh nhật theo phong cách **Phonecert** (màn hình điện thoại) bằng **Alight Motion**.
> Made by: **vxb**

---

## 📁 Các file trong project

| File | Mô tả |
|------|-------|
| `Happy_Birthday_Phonecert__by__vxb_.xml` | File project chính – import vào Alight Motion |
| `màu.xml` | File chỉnh màu (color grading) – import riêng để chỉnh màu |
| `_Pngtree_mobile_phone_green_screen_smartphone_8663719.png` | Ảnh khung điện thoại (green screen) |
| `CherryBombOne-Regular.ttf` | Font chữ sử dụng trong video |
| `Sound_Happy_Birthday_Phonecert.mp3` | Nhạc nền của video |

---

## 📲 Cách sử dụng

### Bước 1 – Tải file về
Nhấn **Code → Download ZIP** hoặc clone về:
```
git clone https://github.com/TÊN_BẠN/happy-birthday-phonecert.git
```

### Bước 2 – Cài font
- Chuyển file `CherryBombOne-Regular.ttf` vào bộ nhớ điện thoại
- Cài đặt font (nhấn vào file hoặc dùng app cài font)

### Bước 3 – Import nhạc & ảnh
Chuyển các file sau vào **Thư viện ảnh / âm thanh** của điện thoại:
- `Sound_Happy_Birthday_Phonecert.mp3`
- `_Pngtree_mobile_phone_green_screen_smartphone_8663719.png`

### Bước 4 – Import vào Alight Motion
1. Mở **Alight Motion**
2. Nhấn dấu **+** → **Import project**
3. Chọn file `Happy_Birthday_Phonecert__by__vxb_.xml`
4. Ghép các media còn thiếu theo hướng dẫn trong app

### Bước 5 – (Tuỳ chọn) Import màu
- Import thêm `màu.xml` để áp dụng bộ màu đi kèm

---

## ✏️ Tuỳ chỉnh

- Thay **tên người nhận** trong các layer Text
- Thay **ảnh nhân vật** bằng ảnh của bạn (layer có nhãn `retouch_...`)
- Thay **ảnh nền** (layer `background [E77202E].png`)

---

## ⚙️ Yêu cầu

- **Alight Motion** phiên bản **5.0+** (Android/iOS)
- Màn hình xuất: **1440 × 1080**, **60fps**, thời lượng ~26 giây

---

## 📌 Lưu ý

- Một số ảnh nhân vật **không đính kèm** trong repo (ảnh riêng tư) — bạn cần tự thay bằng ảnh của mình.
- Nhạc sử dụng cho mục đích **cá nhân, phi thương mại**.

---

*Nếu dùng template này, hãy credit: **by vxb** 💖*
